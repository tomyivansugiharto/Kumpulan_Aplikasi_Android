package com.tyhartstudio.datardanruang;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.ContactsContract;
import android.widget.Toast;

import com.tyhartstudio.datardanruang.bangundatar.DataDatar;
import com.tyhartstudio.datardanruang.bangundatar.Datar;
import com.tyhartstudio.datardanruang.bangundatar.ListDatarAdapter;
import com.tyhartstudio.datardanruang.bangundatar.content.Lingkaran;
import com.tyhartstudio.datardanruang.bangundatar.content.Persegi;
import com.tyhartstudio.datardanruang.bangundatar.content.Segitiga;
import com.tyhartstudio.datardanruang.bangunruang.content.Limas;
import com.tyhartstudio.datardanruang.bangunruang.content.Prisma;
import com.tyhartstudio.datardanruang.bangunruang.content.Tabung;

import java.util.ArrayList;

public class MenuDatar extends AppCompatActivity {
    private RecyclerView rvDatar;
    private long lastClick = 0;
    private String title = "Menu Datar";
    private ArrayList<Datar> list = new ArrayList<>();

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    private void showSelectedDatar(Datar datar) {
        Toast.makeText(this, "Kamu memilih " + datar.getDatar(), Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_datar);
        setActionBarTitle(title);

        rvDatar = findViewById(R.id.rv_itemDatar);
        rvDatar.setHasFixedSize(true);

        list.addAll(DataDatar.getListData());
        showRecyclerList();
    }

    private void showRecyclerList() {
        rvDatar.setLayoutManager(new LinearLayoutManager(this));
        ListDatarAdapter listDatarAdapter = new ListDatarAdapter(list);
        rvDatar.setAdapter(listDatarAdapter);

        listDatarAdapter.setOnItemClickCallback(new ListDatarAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Datar data) {
                showSelectedDatar(data);

                // Untuk mengantisipasi adanya bug double klik
                if (SystemClock.elapsedRealtime() - lastClick < 1000) {
                    return;
                } lastClick = SystemClock.elapsedRealtime();

                switch (data.getId()) {
                    case 0 :
                        Intent movePersegi = new Intent(MenuDatar.this, Persegi.class);
                        startActivity(movePersegi);
                        break;
                    case 1 :
                        Intent moveLingkaran = new Intent(MenuDatar.this, Lingkaran.class);
                        startActivity(moveLingkaran);
                        break;
                    case 2 :
                        Intent moveSegitiga = new Intent(MenuDatar.this, Segitiga.class);
                        startActivity(moveSegitiga);
                        break;
                }
            }
        });
    }
}