package com.tyhartstudio.datardanruang.bangundatar.content;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tyhartstudio.datardanruang.R;

public class Lingkaran extends AppCompatActivity implements View.OnClickListener {

    private EditText edtJari;
    Button btnCalLuas;
    Button btnCalKeliling;
    private TextView tvHasil, tvDiket, tvRumus;
    private String title = "Lingkaran";

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lingkaran);
        setActionBarTitle(title);

        // Inisialisasi EditText
        edtJari = (EditText) findViewById(R.id.edt_jari);

        // Inisialisasi TextView
        tvRumus = (TextView) findViewById(R.id.tv_rumus);
        tvDiket = (TextView) findViewById(R.id.tv_diket);
        tvHasil = (TextView) findViewById(R.id.tv_hasil);

        // Inisalisasi Button
        btnCalLuas = (Button) findViewById(R.id.btn_calLuas);
        btnCalLuas.setOnClickListener(this);

        btnCalKeliling = (Button) findViewById(R.id.btn_calKeliling);
        btnCalKeliling.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        // Button Volume
        if (v.getId() == R.id.btn_calLuas) {
            // Perintah untuk tidak mengkosongkan EditText
            String inputJari = edtJari.getText().toString().trim();

            boolean isEmptyField = false;
            boolean isInvalidDouble = false;

            if (TextUtils.isEmpty(inputJari)) {
                isEmptyField = true;
                edtJari.setError("Isi dulu !!!");
            }

            // Perintah untuk peringatan angka pada EditText
            Double jari = toDouble(inputJari);
            if (jari == null) {
                isInvalidDouble = true;
                edtJari.setError("Isi angka bukan huruf!!!");
            }

            if (!isEmptyField && !isInvalidDouble) {
                String diket = "\nDiketahui : " +
                        "\n > Jari : " +
                        inputJari +
                        "\n" + "\nDitanya : \n" +
                        "Berapakah Luas dari bangun datar tersebut ? \n" +
                        "\nHasil :";
                String rumus = "Luas = Phi x Jari-jari(r)^2";
                double luas = Math.PI * Math.pow(jari,2);
                tvDiket.setText(diket);
                tvRumus.setText(rumus);
                tvHasil.setText(String.valueOf(luas) + " cm");
            }
        }

        // Button Volume
        if (v.getId() == R.id.btn_calKeliling) {
            // Perintah untuk tidak mengkosongkan EditText
            String inputJari = edtJari.getText().toString().trim();

            boolean isEmptyField = false;
            boolean isInvalidDouble = false;

            if (TextUtils.isEmpty(inputJari)) {
                isEmptyField = true;
                edtJari.setError("Isi dulu !!!");
            }

            // Perintah untuk peringatan angka pada EditText
            Double jari = toDouble(inputJari);
            if (jari == null) {
                isInvalidDouble = true;
                edtJari.setError("Isi angka bukan huruf!!!");
            }

            if (!isEmptyField && !isInvalidDouble) {
                String diket = "\nDiketahui : " +
                        "\n > Jari : " +
                        inputJari +
                        "\n" + "\nDitanya : \n" +
                        "Berapakah Keliling dari bangun datar tersebut ? \n" +
                        "\nHasil :";
                String rumus = "Keliling = 2 x Phi x Diameter(d)";
                double keliling = 2 * Math.PI * Math.pow(jari,2);
                tvDiket.setText(diket);
                tvRumus.setText(rumus);
                tvHasil.setText(String.valueOf(keliling) + " cm");
            }
        }
    }

    private Double toDouble(String string) {
        try {
            return Double.valueOf(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}