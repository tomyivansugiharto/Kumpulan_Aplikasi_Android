package com.tyhartstudio.datardanruang.bangundatar;

import com.tyhartstudio.datardanruang.R;

import java.util.ArrayList;

public class DataDatar {
    private static int[] namaId = {
            0,
            1,
            2,
            3,
            4
    };

    private static String[] namaDatar = {
            "Persegi",
            "Lingkaran",
            "Segitiga"
    };

    private static String[] detailDatar = {
            "Luas, Keliling",
            "Luas, Keliling",
            "Luas, keliling"
    };

    private static int[] gambarDatar = {
            R.drawable.persegi,
            R.drawable.lingkaran,
            R.drawable.segitiga
    };

    public static ArrayList<Datar> getListData() {
        ArrayList<Datar> list = new ArrayList<>();
        for (int position = 0; position < namaDatar.length; position++) {
            Datar datar = new Datar();
            datar.setId(namaId[position]);
            datar.setDatar(namaDatar[position]);
            datar.setDetail(detailDatar[position]);
            datar.setImage(gambarDatar[position]);
            list.add(datar);
        }
        return list;
    };
}
