package com.tyhartstudio.datardanruang;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.icu.text.RelativeDateTimeFormatter;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import com.tyhartstudio.datardanruang.bangunruang.DataRuang;
import com.tyhartstudio.datardanruang.bangunruang.ListRuangAdapter;
import com.tyhartstudio.datardanruang.bangunruang.Ruang;
import com.tyhartstudio.datardanruang.bangunruang.content.Limas;
import com.tyhartstudio.datardanruang.bangunruang.content.Prisma;
import com.tyhartstudio.datardanruang.bangunruang.content.Tabung;

import java.util.ArrayList;

public class MenuRuang extends AppCompatActivity {
    private RecyclerView rvRuang;
    private long lastClick = 0;
    private String title = "Menu Ruang";
    private ArrayList<Ruang> list = new ArrayList<>();

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    private void showSelectedRuang(Ruang ruang) {
        Toast.makeText(this, "Kamu memilih " + ruang.getRuang(), Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_ruang);
        setActionBarTitle(title);

        rvRuang = findViewById(R.id.rv_itemRuang);
        rvRuang.setHasFixedSize(true);

        list.addAll(DataRuang.getListData());
        showRecyclerList();
    }

    private void showRecyclerList() {
        rvRuang.setLayoutManager(new LinearLayoutManager(this));
        ListRuangAdapter listRuangAdapter = new ListRuangAdapter(list);
        rvRuang.setAdapter(listRuangAdapter);

        listRuangAdapter.setOnItemClickCallback(new ListRuangAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Ruang data) {
                showSelectedRuang(data);

                // Untuk mengantisipasi adanya bug double klik
                if (SystemClock.elapsedRealtime() - lastClick < 1000) {
                    return;
                } lastClick = SystemClock.elapsedRealtime();

                switch (data.getId()) {
                    case 0 :
                        Intent moveLimas = new Intent(MenuRuang.this, Limas.class);
                        startActivity(moveLimas);
                        break;
                    case 1 :
                        Intent moveTabung = new Intent(MenuRuang.this, Tabung.class);
                        startActivity(moveTabung);
                        break;
                    case 2 :
                        Intent movePrisma = new Intent(MenuRuang.this, Prisma.class);
                        startActivity(movePrisma);
                        break;
                }


            }
        });
    }
}