package com.tyhartstudio.datardanruang.bangunruang.content;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tyhartstudio.datardanruang.R;

public class Tabung extends AppCompatActivity implements View.OnClickListener {

    private EditText edtJari;
    private EditText edtTinggi;
    Button btnCalLuas;
    Button btnCalVolume;
    private TextView tvHasil, tvDiket, tvRumus;
    private String title = "Tabung";

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tabung);
        setActionBarTitle(title);

        // Inisialisasi EditText
        edtJari = (EditText) findViewById(R.id.edt_jari);
        edtTinggi = (EditText) findViewById(R.id.edt_tinggi);

        // Inisialisasi TextView
        tvRumus = (TextView) findViewById(R.id.tv_rumus);
        tvDiket = (TextView) findViewById(R.id.tv_diket);
        tvHasil = (TextView) findViewById(R.id.tv_hasil);

        // Inisalisasi Button
        btnCalLuas = (Button) findViewById(R.id.btn_calLuas);
        btnCalLuas.setOnClickListener(this);

        btnCalVolume = (Button) findViewById(R.id.btn_calVolume);
        btnCalVolume.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        // Button Volume
        if (v.getId() == R.id.btn_calVolume) {
            // Perintah untuk tidak mengkosongkan EditText
            String inputJari = edtJari.getText().toString().trim();
            String inputTinggi = edtTinggi.getText().toString().trim();
            boolean isEmptyField = false;
            boolean isInvalidDouble = false;

            if (TextUtils.isEmpty(inputJari)) {
                isEmptyField = true;
                edtJari.setError("Isi dulu !!!");
            }
            if (TextUtils.isEmpty(inputTinggi)) {
                isEmptyField = true;
                edtTinggi.setError("Isi dulu !!!");
            }

            // Perintah untuk peringatan angka pada EditText
            Double jari = toDouble(inputJari);
            Double tinggi = toDouble(inputTinggi);
            if (jari == null) {
                isInvalidDouble = true;
                edtJari.setError("Isi angka bukan huruf!!!");
            }
            if (tinggi == null) {
                isInvalidDouble = true;
                edtTinggi.setError("Isi angka bukan huruf!!!");
            }

            if (!isEmptyField && !isInvalidDouble) {
                String diket = "\nDiketahui : " + "\n > Jari-jari : " + inputJari +
                        "\n > Tinggi : " + inputTinggi + "\n" + "\nDitanya : \n" +
                        "Berapakah Volume dari bangun ruang tersebut ? \n" +
                        "\nHasil :";
                String rumus = "Volume = Phi x r^2 x Tinggi ";
                double volume = Math.PI * Math.pow(jari,2) * tinggi ;
                tvDiket.setText(diket);
                tvRumus.setText(rumus);
                tvHasil.setText(String.valueOf(volume) + " cm");
            }
        }

        // Button Luas Permukaan
        if (v.getId() == R.id.btn_calLuas) {
            // Perintah untuk tidak mengkosongkan EditText
            String inputJari = edtJari.getText().toString().trim();
            String inputTinggi = edtTinggi.getText().toString().trim();
            boolean isEmptyField = false;
            boolean isInvalidDouble = false;

            if (TextUtils.isEmpty(inputJari)) {
                isEmptyField = true;
                edtJari.setError("Isi dulu !!!");
            }
            if (TextUtils.isEmpty(inputTinggi)) {
                isEmptyField = true;
                edtTinggi.setError("Isi dulu !!!");
            }

            // Perintah untuk peringatan angka pada EditText
            Double jari = toDouble(inputJari);
            Double tinggi = toDouble(inputTinggi);
            if (jari == null) {
                isInvalidDouble = true;
                edtJari.setError("Isi angka bukan huruf!!!");
            }
            if (tinggi == null) {
                isInvalidDouble = true;
                edtTinggi.setError("Isi angka bukan huruf!!!");
            }

            if (!isEmptyField && !isInvalidDouble) {
                String diket = "\nDiketahui : " + "\n > Jari-jari : " + inputJari +
                        "\n > Tinggi : " + inputTinggi + "\n" + "\nDitanya : \n" +
                        "Berapakah Luas Permukaan dari bangun ruang tersebut ? \n" +
                        "\nHasil :";
                String rumus = "Luas Permukaan = (2 x Luas Alas) + (Keliling Alas x Tinggi)";
                double luas = (2 * (Math.PI * Math.pow(jari,2))) + ((2 * Math.PI * Math.pow(jari,2)) * tinggi);
                tvDiket.setText(diket);
                tvRumus.setText(rumus);
                tvHasil.setText(String.valueOf(luas) + " cm");
            }
        }
    }

    private Double toDouble(String string) {
        try {
            return Double.valueOf(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}