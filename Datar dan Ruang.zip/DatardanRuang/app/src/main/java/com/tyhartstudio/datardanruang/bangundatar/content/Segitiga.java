package com.tyhartstudio.datardanruang.bangundatar.content;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tyhartstudio.datardanruang.R;

public class Segitiga extends AppCompatActivity implements View.OnClickListener {

    private EditText edtAlas;
    private EditText edtSisiMiring;
    private EditText edtTinggi;
    Button btnCalLuas;
    Button btnCalKeliling;
    private TextView tvHasil, tvDiket, tvRumus;
    private String title = "Segitiga";

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segitiga);
        setActionBarTitle(title);

        // Inisialisasi EditText
        edtAlas = (EditText) findViewById(R.id.edt_alas);
        edtSisiMiring = (EditText) findViewById(R.id.edt_sisimiring);
        edtTinggi = (EditText) findViewById(R.id.edt_tinggi);

        // Inisialisasi TextView
        tvRumus = (TextView) findViewById(R.id.tv_rumus);
        tvDiket = (TextView) findViewById(R.id.tv_diket);
        tvHasil = (TextView) findViewById(R.id.tv_hasil);

        // Inisalisasi Button
        btnCalLuas = (Button) findViewById(R.id.btn_calLuas);
        btnCalLuas.setOnClickListener(this);

        btnCalKeliling = (Button) findViewById(R.id.btn_calKeliling);
        btnCalKeliling.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        // Button Luas
        if (v.getId() == R.id.btn_calLuas) {
            // Perintah untuk tidak mengkosongkan EditText
            String inputAlasSegitiga = edtAlas.getText().toString().trim();
            String inputTinggi = edtTinggi.getText().toString().trim();
            boolean isEmptyField = false;
            boolean isInvalidDouble = false;

            if (TextUtils.isEmpty(inputAlasSegitiga)) {
                isEmptyField = true;
                edtAlas.setError("Isi dulu !!!");
            }
            if (TextUtils.isEmpty(inputTinggi)) {
                isEmptyField = true;
                edtTinggi.setError("Isi dulu !!!");
            }

            // Perintah untuk peringatan angka pada EditText
            Double alas = toDouble(inputAlasSegitiga);
            Double tinggi = toDouble(inputTinggi);
            if (alas == null) {
                isInvalidDouble = true;
                edtAlas.setError("Isi angka bukan huruf!!!");
            }
            if (tinggi == null) {
                isInvalidDouble = true;
                edtTinggi.setError("Isi angka bukan huruf!!!");
            }

            if (!isEmptyField && !isInvalidDouble) {
                String diket = "\nDiketahui : " +
                        "\n > Alas Segitiga : " +
                        inputAlasSegitiga +
                        "\n > Tinggi : " +
                        inputTinggi +
                        "\n" + "\nDitanya : \n" +
                        "Berapakah Luas dari bangun ruang tersebut ? \n" +
                        "\nHasil :";
                String rumus = "Luas = 1/2 x Alas x Tinggi ";
                double luas = (alas * tinggi) * 1/2;
                tvDiket.setText(diket);
                tvRumus.setText(rumus);
                tvHasil.setText(String.valueOf(luas) + " cm");
            }
        }

        // Button Keliling
        if (v.getId() == R.id.btn_calKeliling) {
            // Perintah untuk tidak mengkosongkan EditText
            String inputAlasSegitiga = edtAlas.getText().toString().trim();
            String inputSisiMiring = edtSisiMiring.getText().toString().trim();
            String inputTinggi = edtTinggi.getText().toString().trim();
            boolean isEmptyField = false;
            boolean isInvalidDouble = false;

            if (TextUtils.isEmpty(inputAlasSegitiga)) {
                isEmptyField = true;
                edtAlas.setError("Isi dulu !!!");
            }
            if (TextUtils.isEmpty(inputSisiMiring)) {
                isEmptyField = true;
                edtSisiMiring.setError("Isi dulu !!!");
            }
            if (TextUtils.isEmpty(inputTinggi)) {
                isEmptyField = true;
                edtTinggi.setError("Isi dulu !!!");
            }

            // Perintah untuk peringatan angka pada EditText
            Double alas = toDouble(inputAlasSegitiga);
            Double sisimiring = toDouble(inputSisiMiring);
            Double tinggi = toDouble(inputTinggi);
            if (alas == null) {
                isInvalidDouble = true;
                edtAlas.setError("Isi angka bukan huruf!!!");
            }
            if (sisimiring == null) {
                isInvalidDouble = true;
                edtSisiMiring.setError("Isi angka bukan huruf!!!");
            }
            if (tinggi == null) {
                isInvalidDouble = true;
                edtTinggi.setError("Isi angka bukan huruf!!!");
            }

            if (!isEmptyField && !isInvalidDouble) {
                String diket = "\nDiketahui : " +
                        "\n > Alas Segitiga : " +
                        inputAlasSegitiga +
                        "\n > Sisi Miring Segitiga : " +
                        inputSisiMiring +
                        "\n > Tinggi : " +
                        inputTinggi +
                        "\n" + "\nDitanya : \n" +
                        "Berapakah Keliling dari bangun ruang tersebut ? \n" +
                        "\nHasil :";
                String rumus = "Keliling = Alas + Sisi Miring + Tinggi ";
                double keliling = alas + sisimiring + tinggi;
                tvDiket.setText(diket);
                tvRumus.setText(rumus);
                tvHasil.setText(String.valueOf(keliling) + " cm");
            }
        }

    }

    private Double toDouble(String string) {
        try {
            return Double.valueOf(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}