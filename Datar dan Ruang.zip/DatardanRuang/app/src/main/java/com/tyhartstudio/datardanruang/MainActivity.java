package com.tyhartstudio.datardanruang;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private long lastClick = 0;
    private Button bangunRuang;
    private Button bangunDatar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bangunDatar = (Button) findViewById(R.id.btn_datar);
        bangunDatar.setOnClickListener(this);

        bangunRuang = (Button) findViewById(R.id.btn_ruang);
        bangunRuang.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        // Untuk mengantisipasi adanya bug double klik
        if (SystemClock.elapsedRealtime() - lastClick < 1000) {
            return;
        } lastClick = SystemClock.elapsedRealtime();

        switch (v.getId()) {
            case R.id.btn_ruang:
                Intent moveRuang = new Intent(MainActivity.this, MenuRuang.class);
                startActivity(moveRuang);
                break;
            case R.id.btn_datar:
                Intent moveDatar = new Intent(MainActivity.this, MenuDatar.class);
                startActivity(moveDatar);
                break;
        }
    }

    // Main Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        setMode(item.getItemId());
        return super.onOptionsItemSelected(item);
    }

    public void setMode (int selectedMode) {
        switch (selectedMode) {
            case R.id.action_profil :
                Intent moveProfil = new Intent(MainActivity.this, MainProfile.class);
                startActivity(moveProfil);
                break;
        }
    }
}