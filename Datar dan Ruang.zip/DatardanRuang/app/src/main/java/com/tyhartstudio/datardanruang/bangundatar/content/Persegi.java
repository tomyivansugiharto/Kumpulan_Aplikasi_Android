package com.tyhartstudio.datardanruang.bangundatar.content;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.tyhartstudio.datardanruang.R;

public class Persegi extends AppCompatActivity implements View.OnClickListener {

    private EditText edtSisi;
    Button btnCalLuas;
    Button btnCalKeliling;
    private TextView tvHasil, tvDiket, tvRumus;
    private String title = "Persegi";

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persegi);
        setActionBarTitle(title);

        // Inisialisasi EditText
        edtSisi = (EditText) findViewById(R.id.edt_sisi);

        // Inisialisasi TextView
        tvRumus = (TextView) findViewById(R.id.tv_rumus);
        tvDiket = (TextView) findViewById(R.id.tv_diket);
        tvHasil = (TextView) findViewById(R.id.tv_hasil);

        // Inisalisasi Button
        btnCalLuas = (Button) findViewById(R.id.btn_calLuas);
        btnCalLuas.setOnClickListener(this);

        btnCalKeliling = (Button) findViewById(R.id.btn_calKeliling);
        btnCalKeliling.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        // Button Volume
        if (v.getId() == R.id.btn_calLuas) {
            // Perintah untuk tidak mengkosongkan EditText
            String inputSisi = edtSisi.getText().toString().trim();

            boolean isEmptyField = false;
            boolean isInvalidDouble = false;

            if (TextUtils.isEmpty(inputSisi)) {
                isEmptyField = true;
                edtSisi.setError("Isi dulu !!!");
            }

            // Perintah untuk peringatan angka pada EditText
            Double sisi = toDouble(inputSisi);
            if (sisi == null) {
                isInvalidDouble = true;
                edtSisi.setError("Isi angka bukan huruf!!!");
            }

            if (!isEmptyField && !isInvalidDouble) {
                String diket = "\nDiketahui : " +
                        "\n > Sisi : " +
                        inputSisi +
                        "\n" + "\nDitanya : \n" +
                        "Berapakah Luas dari bangun datar tersebut ? \n" +
                        "\nHasil :";
                String rumus = "Luas = Sisi x Sisi";
                double luas = sisi * sisi;
                tvDiket.setText(diket);
                tvRumus.setText(rumus);
                tvHasil.setText(String.valueOf(luas) + " cm");
            }
        }

        if (v.getId() == R.id.btn_calKeliling) {
            // Perintah untuk tidak mengkosongkan EditText
            String inputSisi = edtSisi.getText().toString().trim();

            boolean isEmptyField = false;
            boolean isInvalidDouble = false;

            if (TextUtils.isEmpty(inputSisi)) {
                isEmptyField = true;
                edtSisi.setError("Isi dulu !!!");
            }

            // Perintah untuk peringatan angka pada EditText
            Double sisi = toDouble(inputSisi);
            if (sisi == null) {
                isInvalidDouble = true;
                edtSisi.setError("Isi angka bukan huruf!!!");
            }

            if (!isEmptyField && !isInvalidDouble) {
                String diket = "\nDiketahui : " +
                        "\n > Sisi : " +
                        inputSisi +
                        "\n" + "\nDitanya : \n" +
                        "Berapakah Keliling dari bangun datar tersebut ? \n" +
                        "\nHasil :";
                String rumus = "Keliling = 4 x Sisi";
                double keliling = 4 * sisi;
                tvDiket.setText(diket);
                tvRumus.setText(rumus);
                tvHasil.setText(String.valueOf(keliling) + " cm");
            }
        }
    }

    private Double toDouble(String string) {
        try {
            return Double.valueOf(string);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}