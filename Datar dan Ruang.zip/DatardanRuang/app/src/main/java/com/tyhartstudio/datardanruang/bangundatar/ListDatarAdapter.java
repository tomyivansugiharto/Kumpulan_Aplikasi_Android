package com.tyhartstudio.datardanruang.bangundatar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.tyhartstudio.datardanruang.R;
import com.tyhartstudio.datardanruang.bangunruang.ListRuangAdapter;

import java.util.ArrayList;

public class ListDatarAdapter extends RecyclerView.Adapter<ListDatarAdapter.ListViewHolder> {
    private ArrayList<Datar> listDatar;
    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public ListDatarAdapter(ArrayList<Datar> list) {
        this.listDatar = list;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_datar, viewGroup, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder holder, int position) {
        Datar datar = listDatar.get(position);
        Glide.with(holder.itemView.getContext())
                .load(datar.getImage())
                .apply(new RequestOptions().override(55,55))
                .into(holder.gambarDatar);
        holder.tvNama.setText(datar.getDatar());
        holder.tvDetail.setText(datar.getDetail());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(holder.itemView.getContext(),"Kamu Memilih " + listDatar.get(holder.getAdapterPosition()).getDatar(),Toast.LENGTH_SHORT).show();
                onItemClickCallback.onItemClicked(listDatar.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return listDatar.size();
    }

    public static class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView gambarDatar;
        TextView tvNama, tvDetail;

        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            gambarDatar = itemView.findViewById(R.id.img_item_photo);
            tvNama = itemView.findViewById(R.id.tv_item_name);
            tvDetail = itemView.findViewById(R.id.tv_item_detail);
        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(Datar data);
    }
}
