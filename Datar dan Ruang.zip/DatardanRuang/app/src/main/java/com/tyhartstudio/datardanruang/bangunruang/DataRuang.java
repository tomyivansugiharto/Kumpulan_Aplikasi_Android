package com.tyhartstudio.datardanruang.bangunruang;

import com.tyhartstudio.datardanruang.R;

import java.util.ArrayList;

public class DataRuang {
    private static int[] namaId = {
            0,
            1,
            2,
            3,
            4
    };

    private static String[] namaRuang = {
            "Limas",
            "Tabung",
            "Prisma"
    };

    private static String[] detailRuang = {
            "Volume, Luas Permukaan",
            "Volume, Luas Permukaan",
            "Volume, Luas Permukaan"
    };

    private static int[] gambarRuang = {
            R.drawable.limas,
            R.drawable.tabung,
            R.drawable.prisma_segitiga
    };

    public static ArrayList<Ruang> getListData() {
        ArrayList<Ruang> list = new ArrayList<>();
        for (int position = 0; position < namaRuang.length; position++) {
            Ruang ruang = new Ruang();
            ruang.setId(namaId[position]);
            ruang.setRuang(namaRuang[position]);
            ruang.setDetail(detailRuang[position]);
            ruang.setImage(gambarRuang[position]);
            list.add(ruang);
        }
        return list;
    };
}
